# sqless

[![PyPI - Version](https://img.shields.io/pypi/v/sqless.svg)](https://pypi.org/project/sqless)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/sqless.svg)](https://pypi.org/project/sqless)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install sqless
```

## License

`sqless` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
